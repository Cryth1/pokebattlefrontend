import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-pokemon-battle></app-pokemon-battle>`,
  styleUrls: ['./app.component.scss'],

})
export class AppComponent {
  title = 'Devops';

}
